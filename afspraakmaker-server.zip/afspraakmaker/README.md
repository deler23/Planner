# AfspraakMaker NL 🗓️

Een Nederlandse afspraken platform — maak in minuten een eigen boekingspagina.

---

## 🚀 Installatie

### 1. Vereisten
- [Node.js](https://nodejs.org) versie 16 of hoger

### 2. Installeer
```bash
# Pak de map uit en ga erin
cd afspraakmaker

# Installeer dependencies
npm install
```

### 3. Start de server
```bash
npm start
```

Ga naar **http://localhost:3000** in je browser. Klaar! 🎉

---

## ☁️ Online zetten (gratis)

### Optie A — Railway (aanbevolen, gratis)
1. Maak account op [railway.app](https://railway.app)
2. Klik "New Project" → "Deploy from GitHub"
3. Upload deze map naar GitHub
4. Railway deployt automatisch → je krijgt een URL

### Optie B — Render (gratis)
1. Maak account op [render.com](https://render.com)
2. New → Web Service → verbind GitHub repo
3. Build command: `npm install`
4. Start command: `npm start`

### Optie C — VPS (eigen server)
```bash
# Installeer Node.js op je server
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Upload de bestanden en start
npm install
npm start

# Of met PM2 (altijd aan)
npm install -g pm2
pm2 start server.js --name afspraakmaker
pm2 save
```

---

## 📁 Bestandsstructuur

```
afspraakmaker/
├── server.js          ← De server
├── package.json       ← Dependencies
├── data/
│   └── bedrijven.json ← Opgeslagen data (automatisch aangemaakt)
└── public/
    └── index.html     ← De volledige app
```

---

## 🔌 API Endpoints

| Method | URL | Beschrijving |
|--------|-----|-------------|
| GET | /api/bedrijven | Alle bedrijven |
| POST | /api/bedrijven | Nieuw bedrijf |
| PUT | /api/bedrijven/:id | Bedrijf updaten |
| DELETE | /api/bedrijven/:id | Bedrijf verwijderen |
| POST | /api/bedrijven/:id/afspraken | Afspraak toevoegen |
| PUT | /api/bedrijven/:id/afspraken/:aid | Afspraak updaten |
| DELETE | /api/bedrijven/:id/afspraken/:aid | Afspraak verwijderen |

---

## 🌍 Poort aanpassen

Standaard poort is **3000**. Aanpassen:
```bash
PORT=8080 npm start
```

Of zet in een `.env` bestand:
```
PORT=8080
```
