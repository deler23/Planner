const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, 'data', 'bedrijven.json');

// ── Middleware ──────────────────────────────────────────────
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ── Helpers ─────────────────────────────────────────────────
function laadData() {
  if (!fs.existsSync(DATA_FILE)) return [];
  return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
}

function slaOp(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

// ── API Routes ───────────────────────────────────────────────

// Alle bedrijven ophalen
app.get('/api/bedrijven', (req, res) => {
  res.json(laadData());
});

// Eén bedrijf ophalen
app.get('/api/bedrijven/:id', (req, res) => {
  const bedrijven = laadData();
  const b = bedrijven.find(b => b.id === req.params.id);
  if (!b) return res.status(404).json({ error: 'Niet gevonden' });
  res.json(b);
});

// Nieuw bedrijf aanmaken
app.post('/api/bedrijven', (req, res) => {
  const bedrijven = laadData();
  const nieuw = { ...req.body, afspraken: [], aangemaakt: new Date().toISOString() };
  bedrijven.push(nieuw);
  slaOp(bedrijven);
  res.status(201).json(nieuw);
});

// Bedrijf updaten
app.put('/api/bedrijven/:id', (req, res) => {
  const bedrijven = laadData();
  const idx = bedrijven.findIndex(b => b.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Niet gevonden' });
  bedrijven[idx] = { ...bedrijven[idx], ...req.body };
  slaOp(bedrijven);
  res.json(bedrijven[idx]);
});

// Bedrijf verwijderen
app.delete('/api/bedrijven/:id', (req, res) => {
  let bedrijven = laadData();
  bedrijven = bedrijven.filter(b => b.id !== req.params.id);
  slaOp(bedrijven);
  res.json({ ok: true });
});

// Afspraak toevoegen
app.post('/api/bedrijven/:id/afspraken', (req, res) => {
  const bedrijven = laadData();
  const b = bedrijven.find(b => b.id === req.params.id);
  if (!b) return res.status(404).json({ error: 'Niet gevonden' });
  const afspraak = { ...req.body, status: 'nieuw', aangemaakt: new Date().toISOString() };
  b.afspraken = [...(b.afspraken || []), afspraak];
  slaOp(bedrijven);
  res.status(201).json(afspraak);
});

// Afspraak updaten (bevestigen/annuleren)
app.put('/api/bedrijven/:id/afspraken/:aid', (req, res) => {
  const bedrijven = laadData();
  const b = bedrijven.find(b => b.id === req.params.id);
  if (!b) return res.status(404).json({ error: 'Niet gevonden' });
  b.afspraken = b.afspraken.map(a => a.id === req.params.aid ? { ...a, ...req.body } : a);
  slaOp(bedrijven);
  res.json({ ok: true });
});

// Afspraak verwijderen
app.delete('/api/bedrijven/:id/afspraken/:aid', (req, res) => {
  const bedrijven = laadData();
  const b = bedrijven.find(b => b.id === req.params.id);
  if (!b) return res.status(404).json({ error: 'Niet gevonden' });
  b.afspraken = b.afspraken.filter(a => a.id !== req.params.aid);
  slaOp(bedrijven);
  res.json({ ok: true });
});

// ── Alle andere routes → index.html ─────────────────────────
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ── Start server ─────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`✅ AfspraakMaker draait op http://localhost:${PORT}`);
});
